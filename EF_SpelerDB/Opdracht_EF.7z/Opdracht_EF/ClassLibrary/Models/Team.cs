﻿using System;
using System.Collections.Generic;

namespace DataLayer.Models
{
    public partial class Team
    {
        public Team()
        {
            Speler = new HashSet<Speler>();
            TransferNieuwTeam = new HashSet<Transfer>();
            TransferOudTeam = new HashSet<Transfer>();
        }

        public int Stamnummer { get; set; }
        public string Naam { get; set; }
        public string Bijnaam { get; set; }
        public string Trainer { get; set; }

        public virtual ICollection<Speler> Speler { get; set; }
        public virtual ICollection<Transfer> TransferNieuwTeam { get; set; }
        public virtual ICollection<Transfer> TransferOudTeam { get; set; }
    }
}
