﻿using System;
using System.Collections.Generic;

namespace DataLayer.Models
{
    public partial class Transfer
    {
        public int Id { get; set; }
        public int Transferprijs { get; set; }
        public int SpelerId { get; set; }
        public int OudTeamId { get; set; }
        public int NieuwTeamId { get; set; }

        public virtual Team NieuwTeam { get; set; }
        public virtual Team OudTeam { get; set; }
        public virtual Speler Speler { get; set; }
    }
}
