﻿

using DataLayer.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DataLayer.Repositries
{
    public class BuinessManager
    {
        private BuinessContext context;

        public BuinessManager(BuinessContext context)
        {
            this.context = context;
        }

        public void VoegSpelerToe(Speler speler)
        {
            context.Speler.Add(speler);

            context.SaveChanges();
        }

        public void VoegTeamToe(Team team)
        {
            context.Team.Add(team);

            context.SaveChanges();
        }

        public Team SelecteerTeam(int stamnummer)
        {
            return context.Team.Where(t => t.Stamnummer == stamnummer).FirstOrDefault();
        }

        public Speler SelecteerSpeler(int spelerId)
        {
            return context.Speler.Where(s => s.Id == spelerId).FirstOrDefault();
        }

        public void UpdateSpeler(Speler speler)
        {
            context.SaveChanges();
        }

        public void UpdateTeam(Team team)
        {
            //"team" already contains a valid team from the database on entering this methode, so only a DB save is needed
            context.SaveChanges();
        }

        public Transfer SelecteerTransfer(int transferId)
        {
            return context.Transfer.Where(t => t.Id == transferId).FirstOrDefault();
        }

        public void VoegTransferToe(Transfer transfer)
        {
            Speler speler = SelecteerSpeler(transfer.SpelerId);
            if(speler != null)
            {
                context.Transfer.Add(transfer);

                speler.TeamId = transfer.NieuwTeamId;

                context.SaveChanges();
            }
        }
    }
}
