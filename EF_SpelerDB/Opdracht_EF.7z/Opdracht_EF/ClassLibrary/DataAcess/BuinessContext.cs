﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

namespace DataLayer.Models
{
    public partial class BuinessContext : DbContext
    {
        public BuinessContext()
        {
        }

        public BuinessContext(DbContextOptions<BuinessContext> options)
            : base(options)
        {
        }

        public virtual DbSet<Speler> Speler { get; set; }
        public virtual DbSet<Team> Team { get; set; }
        public virtual DbSet<Transfer> Transfer { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
                optionsBuilder.UseSqlServer("Server=.\\sqlexpress;Database=SpelerSQL;Trusted_Connection=True;");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Speler>(entity =>
            {
                entity.HasIndex(e => e.TeamId)
                    .HasName("fk_teamspeler");

                entity.Property(e => e.Id).HasColumnName("id");

                entity.Property(e => e.Naam)
                    .IsRequired()
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.HasOne(d => d.Team)
                    .WithMany(p => p.Speler)
                    .HasForeignKey(d => d.TeamId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("fk_teamspeler");
            });

            modelBuilder.Entity<Team>(entity =>
            {
                entity.HasKey(e => e.Stamnummer)
                    .HasName("PK__Team__88FEC13736A12E1F");

                entity.Property(e => e.Stamnummer).ValueGeneratedNever();

                entity.Property(e => e.Bijnaam)
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.Naam)
                    .IsRequired()
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.Trainer)
                    .IsRequired()
                    .HasMaxLength(255)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<Transfer>(entity =>
            {
                entity.HasIndex(e => e.NieuwTeamId)
                    .HasName("fk_nieuwteamtransfer");

                entity.HasIndex(e => e.OudTeamId)
                    .HasName("fk_oudteamtransfer");

                entity.HasIndex(e => e.SpelerId)
                    .HasName("fk_spelertransfer");

                entity.Property(e => e.Id).HasColumnName("id");

                entity.HasOne(d => d.NieuwTeam)
                    .WithMany(p => p.TransferNieuwTeam)
                    .HasForeignKey(d => d.NieuwTeamId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("fk_nieuwteamtransfer");

                entity.HasOne(d => d.OudTeam)
                    .WithMany(p => p.TransferOudTeam)
                    .HasForeignKey(d => d.OudTeamId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("fk_oudteamtransfer");

                entity.HasOne(d => d.Speler)
                    .WithMany(p => p.Transfer)
                    .HasForeignKey(d => d.SpelerId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("fk_spelertransfer");
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
