﻿using System;

namespace ClassLibrary1
{
    public class Class1
    {
    }
}
