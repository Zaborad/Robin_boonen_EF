﻿
using DataLayer.Models;
using DataLayer.Repositries;
using System;

namespace LeagueApp
{
    class Program
    {
        static private BuinessManager m_Repo;

        static void Main(string[] args)
        {
            m_Repo = new BuinessManager(new BuinessContext());

            Console.WriteLine("Spelers-Teams-Transfers");


            //Team team1 = new Team
            //{
            //    Stamnummer = 5,
            //    Naam = "K.A.A Gent",
            //    Bijnaam = "buffalo",
            //    Trainer = "Jess Thorup"
            //};
            //m_Repo.VoegTeamToe(team1);

            //Team team2 = new Team
            //{
            //    Stamnummer = 33,
            //    Naam = "RSC Anderlecht",
            //    Bijnaam = "paarswit",
            //    Trainer = "Frank Vercauteren"
            //};
            //m_Repo.VoegTeamToe(team2);

            //Team team3 = new Team
            //{
            //    Stamnummer = 15,
            //    Naam = "Club Brugge",
            //    Bijnaam = "FCB",
            //    Trainer = "Pilippe Clement"
            //};
            //m_Repo.VoegTeamToe(team3);


            //Speler speler1 = new Speler
            //{
            //    Naam = "Jonathan David",
            //    Rugnummer = 16,
            //    Team = m_Repo.SelecteerTeam(5),
            //    GeschatteWaarde = 20000
            //};
            //m_Repo.VoegSpelerToe(speler1);

            //Speler speler2 = new Speler
            //{
            //    Naam = "Laurant Depoitre",
            //    Rugnummer = 27,
            //    Team = m_Repo.SelecteerTeam(5),
            //    GeschatteWaarde = 40000
            //};
            //m_Repo.VoegSpelerToe(speler2);

            //Speler speler3 = new Speler
            //{
            //    Naam = "Sven Kums",
            //    Rugnummer = 36,
            //    Team = m_Repo.SelecteerTeam(5),
            //    GeschatteWaarde = 120000
            //};
            //m_Repo.VoegSpelerToe(speler3);

            //Speler speler4 = new Speler
            //{
            //    Naam = "Vincent Kompany",
            //    Rugnummer = 4,
            //    Team = m_Repo.SelecteerTeam(33),
            //    GeschatteWaarde = 230000
            //};
            //m_Repo.VoegSpelerToe(speler4);

            //Speler speler5 = new Speler
            //{
            //    Naam = "Hans Vanaken",
            //    Rugnummer = 50,
            //    Team = m_Repo.SelecteerTeam(15),
            //    GeschatteWaarde = 1000
            //};
            //m_Repo.VoegSpelerToe(speler5);

            //Speler speler6 = new Speler
            //{
            //    Naam = "Elisha Owusu",
            //    Rugnummer = 10,
            //    Team = m_Repo.SelecteerTeam(5),
            //    GeschatteWaarde = 8000
            //};
            //m_Repo.VoegSpelerToe(speler6);

            //Speler speler7 = new Speler
            //{
            //    Naam = "Michel Vlap",
            //    Rugnummer = 66,
            //    Team = m_Repo.SelecteerTeam(33),
            //    GeschatteWaarde = 19000
            //};
            //m_Repo.VoegSpelerToe(speler7);

            //Speler speler8 = new Speler
            //{
            //    Naam = "Nacer Chadli",
            //    Rugnummer = 89,
            //    Team = m_Repo.SelecteerTeam(33),
            //    GeschatteWaarde = 16000
            //};
            //m_Repo.VoegSpelerToe(speler8);



            //Transfer transfer2 = new Transfer();
            //transfer2.SpelerId = 7;
            //transfer2.Transferprijs = 80000;
            //transfer2.OudTeamId = 5;
            //transfer2.NieuwTeamId = 33;
            //m_Repo.VoegTransferToe(transfer2);

            //Transfer transfer3 = new Transfer();
            //transfer3.SpelerId = 8;
            //transfer3.Transferprijs = 250000;
            //transfer3.OudTeamId = 33;
            //transfer3.NieuwTeamId = 15;
            //m_Repo.VoegTransferToe(transfer3);

            //Transfer transfer4 = new Transfer();
            //transfer4.SpelerId = 5;
            //transfer4.Transferprijs = 15000;
            //transfer4.OudTeamId = 5;
            //transfer4.NieuwTeamId = 15;
            //m_Repo.VoegTransferToe(transfer4);



            /*Speler spelerVerander1 = m_Repo.SelecteerSpeler(5);
            spelerVerander1.Naam = "Robin Boonen";
            m_Repo.UpdateSpeler(spelerVerander1);

            Speler spelerVerander2 = m_Repo.SelecteerSpeler(12);
            spelerVerander2.Rugnummer = 2;
            spelerVerander2.GeschatteWaarde = 5000;
            m_Repo.UpdateSpeler(spelerVerander2);*/


            /*Team teamVerander1 = m_Repo.SelecteerTeam(5);
            teamVerander1.Naam = "Gent is de beste";
            teamVerander1.Bijnaam = "the best";
            m_Repo.UpdateTeam(teamVerander1);

            Team teamVerander2 = m_Repo.SelecteerTeam(33);
            teamVerander2.Trainer = "Jean-Marie pfaff";
            m_Repo.UpdateTeam(teamVerander2);*/



        }






    }
}
